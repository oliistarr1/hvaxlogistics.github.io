import { Download, Monitor, Smartphone } from "lucide-react";
import { Button } from "@/components/ui/button";

const DownloadSection = () => {
  return (
    <section id="download" className="py-24 px-4">
      <div className="max-w-4xl mx-auto text-center">
        <h2 className="text-3xl md:text-4xl font-bold mb-4 text-foreground">
          HVAX <span className="text-primary text-glow">Tracker</span>
        </h2>
        <p className="text-muted-foreground mb-12 max-w-xl mx-auto">
          Our custom tracking app logs your deliveries, distance, and speed automatically. Required for all active drivers.
        </p>

        <div className="grid sm:grid-cols-2 gap-6 max-w-lg mx-auto">
          <div className="bg-card border border-border rounded-lg p-8 card-glow hover:border-primary/40 transition-colors flex flex-col items-center">
            <Monitor className="w-12 h-12 text-primary mb-4" />
            <h3 className="font-bold text-foreground mb-2 font-sans">Windows</h3>
            <p className="text-muted-foreground text-sm mb-6">v2.1.0 — 24 MB</p>
            <Button className="w-full gap-2 font-bold">
              <Download className="w-4 h-4" />
              Download .exe
            </Button>
          </div>

          <div className="bg-card border border-border rounded-lg p-8 card-glow hover:border-primary/40 transition-colors flex flex-col items-center">
            <Smartphone className="w-12 h-12 text-primary mb-4" />
            <h3 className="font-bold text-foreground mb-2 font-sans">Mobile</h3>
            <p className="text-muted-foreground text-sm mb-6">Coming Soon</p>
            <Button className="w-full gap-2 font-bold" disabled>
              <Download className="w-4 h-4" />
              Coming Soon
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default DownloadSection;
