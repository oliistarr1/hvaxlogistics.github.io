import { Gauge, Route, ShieldCheck, Clock } from "lucide-react";

const rules = [
  {
    icon: Route,
    title: "20 km / Week",
    description: "Every driver must complete a minimum of 20 kilometers per week to remain active in the company.",
  },
  {
    icon: Gauge,
    title: "Max 90 km/h",
    description: "Speed must not exceed 90 km/h at any time. Safety is our top priority on every haul.",
  },
  {
    icon: ShieldCheck,
    title: "No Reckless Driving",
    description: "Respect traffic laws, other drivers, and the road. Violations may result in removal.",
  },
  {
    icon: Clock,
    title: "Log Your Deliveries",
    description: "Use the HVAX Tracker app to log all jobs. Untracked mileage will not count toward your total.",
  },
];

const RulesSection = () => {
  return (
    <section id="rules" className="py-24 px-4">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-4 text-foreground">
          Company <span className="text-primary text-glow">Rules</span>
        </h2>
        <p className="text-muted-foreground text-center mb-16 max-w-xl mx-auto">
          Simple rules that keep our fleet professional and our community strong.
        </p>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {rules.map((rule) => (
            <div
              key={rule.title}
              className="bg-card border border-border rounded-lg p-6 card-glow hover:border-primary/40 transition-colors group"
            >
              <rule.icon className="w-10 h-10 text-primary mb-4 group-hover:scale-110 transition-transform" />
              <h3 className="text-lg font-bold text-foreground mb-2 font-sans">{rule.title}</h3>
              <p className="text-muted-foreground text-sm leading-relaxed">{rule.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default RulesSection;
