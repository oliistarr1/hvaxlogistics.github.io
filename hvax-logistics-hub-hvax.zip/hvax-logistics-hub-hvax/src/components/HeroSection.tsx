import heroImage from "@/assets/hero-truck.jpg";
import { Button } from "@/components/ui/button";
import { ChevronDown } from "lucide-react";

const HeroSection = () => {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      <img
        src={heroImage}
        alt="Truck on highway at sunset"
        className="absolute inset-0 w-full h-full object-cover"
        width={1920}
        height={1024}
      />
      <div className="absolute inset-0 bg-background/70" />
      <div
        className="absolute inset-x-0 bottom-0 h-40"
        style={{ background: "var(--gradient-hero)" }}
      />

      <div className="relative z-10 text-center px-4 max-w-4xl mx-auto">
        <p className="text-primary font-semibold tracking-[0.3em] uppercase text-sm mb-4 animate-pulse">
          Euro Truck Simulator 2
        </p>
        <h1 className="text-5xl md:text-7xl lg:text-8xl font-black tracking-tight text-foreground mb-2">
          HVAX
        </h1>
        <h2 className="text-2xl md:text-4xl lg:text-5xl font-bold text-primary text-glow mb-6">
          LOGISTICS
        </h2>
        <p className="text-muted-foreground text-lg md:text-xl max-w-2xl mx-auto mb-10">
          Professional virtual trucking across Europe. Discipline. Precision. Community.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button
            variant="default"
            size="lg"
            className="text-lg px-8 py-6 font-bold"
            onClick={() => document.getElementById("apply")?.scrollIntoView({ behavior: "smooth" })}
          >
            Apply Now
          </Button>
          <Button
            variant="outline"
            size="lg"
            className="text-lg px-8 py-6 font-bold border-primary/30 text-primary hover:bg-primary/10"
            onClick={() => document.getElementById("download")?.scrollIntoView({ behavior: "smooth" })}
          >
            Download Tracker
          </Button>
        </div>
      </div>

      <button
        onClick={() => document.getElementById("rules")?.scrollIntoView({ behavior: "smooth" })}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 text-muted-foreground hover:text-primary transition-colors animate-bounce"
      >
        <ChevronDown className="w-8 h-8" />
      </button>
    </section>
  );
};

export default HeroSection;
