import { Button } from "@/components/ui/button";
import { Users, Truck, Globe } from "lucide-react";

const stats = [
  { icon: Users, value: "120+", label: "Active Drivers" },
  { icon: Truck, value: "48,000", label: "km This Month" },
  { icon: Globe, value: "14", label: "Countries" },
];

const ApplySection = () => {
  return (
    <section id="apply" className="py-24 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="bg-card border border-primary/20 rounded-2xl p-8 md:p-16 text-center card-glow relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-transparent pointer-events-none" />
          <div className="relative z-10">
            <h2 className="text-3xl md:text-5xl font-bold mb-4 text-foreground">
              Join <span className="text-primary text-glow">HVAX</span>
            </h2>
            <p className="text-muted-foreground mb-10 max-w-lg mx-auto text-lg">
              Ready to haul across Europe with a professional team? We're always looking for dedicated drivers.
            </p>

            <div className="grid grid-cols-3 gap-4 mb-10 max-w-md mx-auto">
              {stats.map((stat) => (
                <div key={stat.label} className="flex flex-col items-center">
                  <stat.icon className="w-6 h-6 text-primary mb-2" />
                  <span className="text-2xl font-bold text-foreground">{stat.value}</span>
                  <span className="text-xs text-muted-foreground">{stat.label}</span>
                </div>
              ))}
            </div>

            <Button
              size="lg"
              className="text-lg px-12 py-6 font-bold"
              onClick={() => window.open("https://discord.gg/", "_blank")}
            >
              Apply Now
            </Button>
            <p className="text-muted-foreground text-xs mt-4">Applications handled via Discord</p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ApplySection;
