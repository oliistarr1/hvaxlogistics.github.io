import { Trophy, Medal, Award } from "lucide-react";

const drivers = [
  { rank: 1, name: "TruckKing_NL", distance: 847, deliveries: 42, topSpeed: 89 },
  { rank: 2, name: "NightHauler", distance: 723, deliveries: 36, topSpeed: 88 },
  { rank: 3, name: "EuroFreight22", distance: 691, deliveries: 34, topSpeed: 90 },
  { rank: 4, name: "Nordic_Express", distance: 584, deliveries: 29, topSpeed: 87 },
  { rank: 5, name: "AlpineRunner", distance: 512, deliveries: 26, topSpeed: 85 },
  { rank: 6, name: "CargoBoss_DE", distance: 478, deliveries: 24, topSpeed: 90 },
  { rank: 7, name: "RouteMax", distance: 401, deliveries: 20, topSpeed: 86 },
  { rank: 8, name: "SteelWheel_PL", distance: 356, deliveries: 18, topSpeed: 88 },
];

const getRankIcon = (rank: number) => {
  if (rank === 1) return <Trophy className="w-5 h-5 text-yellow-400" />;
  if (rank === 2) return <Medal className="w-5 h-5 text-gray-300" />;
  if (rank === 3) return <Award className="w-5 h-5 text-amber-600" />;
  return <span className="text-muted-foreground text-sm w-5 text-center">#{rank}</span>;
};

const LeaderboardSection = () => {
  return (
    <section id="leaderboard" className="py-24 px-4">
      <div className="max-w-4xl mx-auto">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-4 text-foreground">
          Driver <span className="text-primary text-glow">Leaderboard</span>
        </h2>
        <p className="text-muted-foreground text-center mb-12 max-w-xl mx-auto">
          Top performers this month. Keep hauling to climb the ranks.
        </p>

        <div className="bg-card border border-border rounded-lg overflow-hidden card-glow">
          <div className="grid grid-cols-[3rem_1fr_5rem_4rem_4rem] md:grid-cols-[4rem_1fr_6rem_5rem_5rem] gap-2 px-4 md:px-6 py-3 border-b border-border text-xs uppercase tracking-wider text-muted-foreground font-semibold">
            <span>Rank</span>
            <span>Driver</span>
            <span className="text-right">Distance</span>
            <span className="text-right">Jobs</span>
            <span className="text-right">Top</span>
          </div>

          {drivers.map((driver) => (
            <div
              key={driver.rank}
              className={`grid grid-cols-[3rem_1fr_5rem_4rem_4rem] md:grid-cols-[4rem_1fr_6rem_5rem_5rem] gap-2 px-4 md:px-6 py-4 border-b border-border/50 items-center hover:bg-secondary/50 transition-colors ${
                driver.rank <= 3 ? "bg-primary/5" : ""
              }`}
            >
              <span className="flex items-center">{getRankIcon(driver.rank)}</span>
              <span className="font-semibold text-foreground truncate">{driver.name}</span>
              <span className="text-right text-primary font-bold">{driver.distance} km</span>
              <span className="text-right text-muted-foreground">{driver.deliveries}</span>
              <span className="text-right text-muted-foreground">{driver.topSpeed}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default LeaderboardSection;
