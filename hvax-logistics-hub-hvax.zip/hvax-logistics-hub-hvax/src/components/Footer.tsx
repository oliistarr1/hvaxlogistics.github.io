const Footer = () => (
  <footer className="border-t border-border py-8 px-4">
    <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4 text-sm text-muted-foreground">
      <span style={{ fontFamily: "Orbitron" }} className="font-bold text-foreground">
        HVAX <span className="text-primary">Logistics</span>
      </span>
      <span>© {new Date().getFullYear()} HVAX Logistics — Euro Truck Simulator 2 VTC</span>
    </div>
  </footer>
);

export default Footer;
