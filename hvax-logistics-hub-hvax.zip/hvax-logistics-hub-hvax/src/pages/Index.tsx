import Navbar from "@/components/Navbar";
import HeroSection from "@/components/HeroSection";
import RulesSection from "@/components/RulesSection";
import LeaderboardSection from "@/components/LeaderboardSection";
import DownloadSection from "@/components/DownloadSection";
import ApplySection from "@/components/ApplySection";
import Footer from "@/components/Footer";

const Index = () => (
  <div className="min-h-screen bg-background">
    <Navbar />
    <HeroSection />
    <RulesSection />
    <LeaderboardSection />
    <DownloadSection />
    <ApplySection />
    <Footer />
  </div>
);

export default Index;
